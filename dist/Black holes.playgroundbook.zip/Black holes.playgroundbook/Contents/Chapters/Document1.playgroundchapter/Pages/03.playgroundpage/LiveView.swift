//
//  LiveView.swift
//
//  Copyright (c) 2017 Nils Leif Fischer. All Rights Reserved.
//

import PlaygroundSupport
import UIKit

let page = PlaygroundPage.current

page.liveView = BinarySystemViewController()
